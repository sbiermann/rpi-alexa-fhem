# alexa-fhem
[![npm](https://img.shields.io/npm/v/alexa-fhem.svg?style=plastic)](https://www.npmjs.com/package/alexa-fhem)
[![npm](https://img.shields.io/npm/dt/alexa-fhem.svg?style=plastic)](https://www.npmjs.com/package/alexa-fhem)
[![GitHub last commit](https://img.shields.io/github/last-commit/justme-1968/alexa-fhem.svg?style=plastic)](https://github.com/justme-1968/alexa-fhem)

see https://wiki.fhem.de/wiki/FHEM_Connector and https://wiki.fhem.de/wiki/Alexa-Fhem
